﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RateMyDebate.Controllers
{
    public class RulesController : Controller
    {
        //
        // GET: /Rules/
        public ActionResult Index()
        {
            return View();
        }
	}
}