﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using RateMyDebate.Models;

namespace RateMyDebate.Hubs
{

    public class ChatHub : Hub
    {
        static readonly HashSet<int> DebateGroups = new HashSet<int>(); 
    
        public void JoinDebateGroup(int debateId)
        {
            String Id = debateId.ToString();
            if (!DebateGroups.Contains(debateId)) return;
            Groups.Add(Context.ConnectionId, Id);
        }

        public void CreateDebateGroup(int debateId)
        {
            String Id = debateId.ToString();
            if(DebateGroups.Contains(debateId)) return;
            DebateGroups.Add(debateId);
            JoinDebateGroup(debateId);
            Clients.All.debateGroups(new[] {debateId});
        }

        public void LeaveDebateGroup(int debateId)
        {
            
        }

        public void Send(string name, string message)
        {
            Clients.All.broadcastMessage(name, message);
        }
    }

}