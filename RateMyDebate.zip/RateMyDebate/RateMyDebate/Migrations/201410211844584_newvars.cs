namespace RateMyDebate.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class newvars : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.VoteLists",
                c => new
                    {
                        VoteListId = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.VoteListId);
            
            AddColumn("dbo.Debates", "ChallengerVotesId", c => c.Int(nullable: false));
            AddColumn("dbo.Debates", "CreatorVotesId", c => c.Int(nullable: false));
            AddColumn("dbo.Debates", "ChallengerVotesList_VoteListId", c => c.Int());
            AddColumn("dbo.Debates", "CreatorVotesList_VoteListId", c => c.Int());
            AddColumn("dbo.UserInformations", "VoteList_VoteListId", c => c.Int());
            CreateIndex("dbo.UserInformations", "VoteList_VoteListId");
            CreateIndex("dbo.Debates", "ChallengerVotesList_VoteListId");
            CreateIndex("dbo.Debates", "CreatorVotesList_VoteListId");
            AddForeignKey("dbo.UserInformations", "VoteList_VoteListId", "dbo.VoteLists", "VoteListId");
            AddForeignKey("dbo.Debates", "ChallengerVotesList_VoteListId", "dbo.VoteLists", "VoteListId");
            AddForeignKey("dbo.Debates", "CreatorVotesList_VoteListId", "dbo.VoteLists", "VoteListId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Debates", "CreatorVotesList_VoteListId", "dbo.VoteLists");
            DropForeignKey("dbo.Debates", "ChallengerVotesList_VoteListId", "dbo.VoteLists");
            DropForeignKey("dbo.UserInformations", "VoteList_VoteListId", "dbo.VoteLists");
            DropIndex("dbo.Debates", new[] { "CreatorVotesList_VoteListId" });
            DropIndex("dbo.Debates", new[] { "ChallengerVotesList_VoteListId" });
            DropIndex("dbo.UserInformations", new[] { "VoteList_VoteListId" });
            DropColumn("dbo.UserInformations", "VoteList_VoteListId");
            DropColumn("dbo.Debates", "CreatorVotesList_VoteListId");
            DropColumn("dbo.Debates", "ChallengerVotesList_VoteListId");
            DropColumn("dbo.Debates", "CreatorVotesId");
            DropColumn("dbo.Debates", "ChallengerVotesId");
            DropTable("dbo.VoteLists");
        }
    }
}
