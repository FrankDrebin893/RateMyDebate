namespace RateMyDebate.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class newvars2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.UserInformations", "VoteList_VoteListId", "dbo.VoteLists");
            DropForeignKey("dbo.Debates", "ChallengerVotesList_VoteListId", "dbo.VoteLists");
            DropForeignKey("dbo.Debates", "CreatorVotesList_VoteListId", "dbo.VoteLists");
            DropIndex("dbo.UserInformations", new[] { "VoteList_VoteListId" });
            DropIndex("dbo.Debates", new[] { "ChallengerVotesList_VoteListId" });
            DropIndex("dbo.Debates", new[] { "CreatorVotesList_VoteListId" });
            AddColumn("dbo.Debates", "Votes_VoteListId", c => c.Int());
            AddColumn("dbo.VoteLists", "VoterId", c => c.Int(nullable: false));
            AddColumn("dbo.VoteLists", "DebateId", c => c.Int(nullable: false));
            AddColumn("dbo.VoteLists", "Vote", c => c.Int(nullable: false));
            CreateIndex("dbo.Debates", "Votes_VoteListId");
            AddForeignKey("dbo.Debates", "Votes_VoteListId", "dbo.VoteLists", "VoteListId");
            DropColumn("dbo.Debates", "ChallengerVotesId");
            DropColumn("dbo.Debates", "CreatorVotesId");
            DropColumn("dbo.Debates", "ChallengerVotesList_VoteListId");
            DropColumn("dbo.Debates", "CreatorVotesList_VoteListId");
            DropColumn("dbo.UserInformations", "VoteList_VoteListId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.UserInformations", "VoteList_VoteListId", c => c.Int());
            AddColumn("dbo.Debates", "CreatorVotesList_VoteListId", c => c.Int());
            AddColumn("dbo.Debates", "ChallengerVotesList_VoteListId", c => c.Int());
            AddColumn("dbo.Debates", "CreatorVotesId", c => c.Int(nullable: false));
            AddColumn("dbo.Debates", "ChallengerVotesId", c => c.Int(nullable: false));
            DropForeignKey("dbo.Debates", "Votes_VoteListId", "dbo.VoteLists");
            DropIndex("dbo.Debates", new[] { "Votes_VoteListId" });
            DropColumn("dbo.VoteLists", "Vote");
            DropColumn("dbo.VoteLists", "DebateId");
            DropColumn("dbo.VoteLists", "VoterId");
            DropColumn("dbo.Debates", "Votes_VoteListId");
            CreateIndex("dbo.Debates", "CreatorVotesList_VoteListId");
            CreateIndex("dbo.Debates", "ChallengerVotesList_VoteListId");
            CreateIndex("dbo.UserInformations", "VoteList_VoteListId");
            AddForeignKey("dbo.Debates", "CreatorVotesList_VoteListId", "dbo.VoteLists", "VoteListId");
            AddForeignKey("dbo.Debates", "ChallengerVotesList_VoteListId", "dbo.VoteLists", "VoteListId");
            AddForeignKey("dbo.UserInformations", "VoteList_VoteListId", "dbo.VoteLists", "VoteListId");
        }
    }
}
