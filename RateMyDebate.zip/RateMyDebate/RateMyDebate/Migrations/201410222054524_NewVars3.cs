namespace RateMyDebate.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NewVars3 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Debates", "Votes_VoteListId", "dbo.VoteLists");
            DropIndex("dbo.Debates", new[] { "Votes_VoteListId" });
            DropColumn("dbo.Debates", "Votes_VoteListId");
            DropTable("dbo.VoteLists");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.VoteLists",
                c => new
                    {
                        VoteListId = c.Int(nullable: false, identity: true),
                        VoterId = c.Int(nullable: false),
                        DebateId = c.Int(nullable: false),
                        Vote = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.VoteListId);
            
            AddColumn("dbo.Debates", "Votes_VoteListId", c => c.Int());
            CreateIndex("dbo.Debates", "Votes_VoteListId");
            AddForeignKey("dbo.Debates", "Votes_VoteListId", "dbo.VoteLists", "VoteListId");
        }
    }
}
